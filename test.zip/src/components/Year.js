import React from 'react'
import PropTypes from 'prop-types'

const Year = props => {
    return (
        <div className="year">
        <ul>
          <li>2020</li>
          <li>2021</li>
          <li>2022</li>
          <li>2023</li>
          <li>2024</li>
          <li>2025</li>
        </ul>
      </div>
    )
}

Year.propTypes = {

}

export default Year;
